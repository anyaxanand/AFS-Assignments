import Scoreboard from './components/Scoreboard'

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f2027] via-[#203a43] to-[#2c5364] flex justify-center items-center p-6">
      <div className="w-full max-w-5xl h-full bg-white/20 backdrop-blur-xl border border-white/30 rounded-3xl shadow-2xl p-10 flex justify-center items-center animate-fade-in">
        <Scoreboard />
      </div>
    </div>
  )
}

export default App
