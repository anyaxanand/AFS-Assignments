function Navbar() {
    return (
      <nav className="navbar">
        <h1> My Password Manager</h1>
      </nav>
    )
  }
  
  export default Navbar
  